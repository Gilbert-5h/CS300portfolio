//============================================================================
// Name        : BinarySearchTree.cpp
// Author      : Gilbert Hernandez
// Version     : 1.0
// Copyright   : Copyright � 2017 SNHU COCE
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm> // For sorting

using namespace std;

// Define a structure to hold course information
struct Course {
    string courseNumber;
    string title;
    string prerequisites;

    Course() : courseNumber(""), title(""), prerequisites("") {}
    Course(string num, string ttl, string prereq) : courseNumber(num), title(ttl), prerequisites(prereq) {}
};

// Internal structure for tree node
struct Node {
    Course course;
    Node* left;
    Node* right;

    // default constructor
    Node() : left(nullptr), right(nullptr) {}

    // initialize with a course
    Node(Course aCourse) : Node() {
        course = aCourse;
    }
};

// Binary Search Tree class
class BinarySearchTree {
private:
    Node* root;

    void addNode(Node* node, Course course);
    void inOrder(Node* node);

public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void Insert(Course course);
    Course Search(string courseNumber);
    void InOrder();
};

BinarySearchTree::BinarySearchTree() {
    root = nullptr;
}

BinarySearchTree::~BinarySearchTree() {
    // Implement this for memory cleanup
}

void BinarySearchTree::Insert(Course course) {
    if (root == nullptr) {
        root = new Node(course);
    }
    else {
        addNode(root, course);
    }
}

Course BinarySearchTree::Search(string courseNumber) {
    Node* current = root;

    while (current != nullptr && current->course.courseNumber != courseNumber) {
        if (courseNumber < current->course.courseNumber) {
            current = current->left;
        }
        else {
            current = current->right;
        }
    }

    Course course("", "", "");

    if (current != nullptr) {
        course = current->course;
    }

    return course;
}

void BinarySearchTree::addNode(Node* node, Course course) {
    if (course.courseNumber < node->course.courseNumber) {
        if (node->left == nullptr) {
            node->left = new Node(course);
        }
        else {
            addNode(node->left, course);
        }
    }
    else {
        if (node->right == nullptr) {
            node->right = new Node(course);
        }
        else {
            addNode(node->right, course);
        }
    }
}

void BinarySearchTree::InOrder() {
    inOrder(root);
}

void BinarySearchTree::inOrder(Node* node) {
    if (node != nullptr) {
        inOrder(node->left);
        cout << node->course.courseNumber << ", " << node->course.title << endl;
        inOrder(node->right);
    }
}

int main() {
    BinarySearchTree bst;

    cout << "Welcome to the course planner." << endl;

    int choice = 0;
    while (choice != 4) {
        cout << "1. Load Data Structure." << endl;
        cout << "2. Print Course List." << endl;
        cout << "3. Print Course." << endl;
        cout << "4. Exit" << endl;

        cout << "What would you like to do? ";
        cin >> choice;

        switch (choice) {
        case 1: {
            string fileName;
            cout << "Enter the file name that contains the course data: ";
            cin >> fileName;

            ifstream file(fileName);
            if (file.is_open()) {
                string line;
                while (getline(file, line)) {
                    stringstream ss(line);
                    string courseNumber, title, prerequisites;
                    getline(ss, courseNumber, ',');
                    getline(ss, title, ',');
                    getline(ss, prerequisites);

                    Course course(courseNumber, title, prerequisites);
                    bst.Insert(course);
                }

                file.close();
                cout << "Course data loaded successfully." << endl;
            }
            else {
                cout << "Error opening the file." << endl;
            }
            break;
        }

        case 2:
            cout << "Here is a sample schedule:" << endl;
            bst.InOrder();
            break;

        case 3: {
            string courseNumber;
            cout << "What course do you want to know about? ";
            cin >> courseNumber;

            Course course = bst.Search(courseNumber);

            if (course.courseNumber != "") {
                cout << course.courseNumber << ", " << course.title << endl;
                cout << "Prerequisites: " << course.prerequisites << endl;
            }
            else {
                cout << "Course not found." << endl;
            }
            break;
        }

        case 4:
            cout << "Thank you for using the course planner!" << endl;
            break;

        default:
            cout << choice << " is not a valid option." << endl;
            break;
        }
    }

    return 0;
}